﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace kval
{
    public partial class Form1 : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlCommandBuilder sqlBuilder = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private DataSet dataSet = null;
        private bool newRowAdding = false;

        public Form1()
        {
            InitializeComponent();
        }


        private void LoadData()
        {
            try
            {
                sqlDataAdapter = new SqlDataAdapter("SELECT *, 'Delete' AS [Command] FROM музСборник", sqlConnection);

                sqlBuilder = new SqlCommandBuilder(sqlDataAdapter);

                sqlBuilder.GetInsertCommand();
                sqlBuilder.GetUpdateCommand();
                sqlBuilder.GetDeleteCommand();

                dataSet = new DataSet();

                sqlDataAdapter.Fill(dataSet, "музСборник");

                dataGridView1.DataSource = dataSet.Tables["музСборник"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();

                    dataGridView1[6, i] = linkCell;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReloadData()
        {
            try
            {
                dataSet.Tables["музСборник"].Clear();

                sqlDataAdapter.Fill(dataSet, "музСборник");

                dataGridView1.DataSource = dataSet.Tables["музСборник"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();

                    dataGridView1[6, i] = linkCell;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "основные_фондыDataSet.Отделы". При необходимости она может быть перемещена или удалена.
            // this.отделыTableAdapter.Fill(this.основные_фондыDataSet.Отделы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "основные_фондыDataSet.Типы_фондов". При необходимости она может быть перемещена или удалена.
            //this.типы_фондовTableAdapter.Fill(this.основные_фондыDataSet.Типы_фондов);
            sqlConnection = new SqlConnection(@"Data Source=242-5\SQLEXPRESS;Initial Catalog=""Музыкальный сборник"";Integrated Security=True");

            sqlConnection.Open();

            LoadData();
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        
        {
            try
            {
                if (e.ColumnIndex == 6)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();

                    if (task == "Delete")
                    {
                        if (MessageBox.Show("Delete this String?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);

                            dataSet.Tables["музСборник"].Rows[rowIndex].Delete();

                            sqlDataAdapter.Update(dataSet, "музСборник");
                        }
                    }
                    else if (task == "Insert")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;

                        DataRow row = dataSet.Tables["музСборник"].NewRow();

                        row["id"] = dataGridView1.Rows[rowIndex].Cells["id"].Value;
                        row["название композиции"] = dataGridView1.Rows[rowIndex].Cells["название композиции"].Value;
                        row["автор"] = dataGridView1.Rows[rowIndex].Cells["автор"].Value;
                        row["время композиции"] = dataGridView1.Rows[rowIndex].Cells["время композиции"].Value;
                        row["жанр"] = dataGridView1.Rows[rowIndex].Cells["жанр"].Value;
                        row["альбом"] = dataGridView1.Rows[rowIndex].Cells["альбом"].Value;
                        // row["Email"] = dataGridView1.Rows[rowIndex].Cells["Email"].Value;
                        // row["Phone"] = dataGridView1.Rows[rowIndex].Cells["Phone"].Value;

                        dataSet.Tables["музСборник"].Rows.Add(row);

                        dataSet.Tables["музСборник"].Rows.RemoveAt(dataSet.Tables["музСборник"].Rows.Count - 1);

                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);

                        dataGridView1.Rows[e.RowIndex].Cells[6].Value = "Delete";

                        sqlDataAdapter.Update(dataSet, "музСборник");

                        newRowAdding = false;
                    }
                    else if (task == "Update")
                    {
                        int r = e.RowIndex;

                        dataSet.Tables["музСборник"].Rows[r]["название композиции"] = dataGridView1.Rows[r].Cells["название композиции"].Value;
                        dataSet.Tables["музСборник"].Rows[r]["автор"] = dataGridView1.Rows[r].Cells["автор"].Value;
                        dataSet.Tables["музСборник"].Rows[r]["время композицииа"] = dataGridView1.Rows[r].Cells["время композиции"].Value;
                        dataSet.Tables["музСборник"].Rows[r]["жанр"] = dataGridView1.Rows[r].Cells["жанр"].Value;
                        dataSet.Tables["музСборник"].Rows[r]["альбом"] = dataGridView1.Rows[r].Cells["альбом"].Value;
                        // dataSet.Tables["Users"].Rows[r]["Phone"] = dataGridView1.Rows[r].Cells["Phone"].Value;

                        sqlDataAdapter.Update(dataSet, "музСборник");

                        dataGridView1.Rows[e.RowIndex].Cells[6].Value = "Delete";
                    }
                    ReloadData();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                if (newRowAdding == false)
                {
                    newRowAdding = true;

                    int lastRow = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRow];

                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();

                    dataGridView1[6, lastRow] = linkCell;

                    row.Cells["Command"].Value = "Insert";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (newRowAdding == false)
                {


                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingRow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();

                    dataGridView1[6, rowIndex] = linkCell;

                    editingRow.Cells["Command"].Value = "Update";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.KeyPress -= new KeyPressEventHandler(Column_KeyPress);

            if (dataGridView1.CurrentCell.ColumnIndex == 6)
            {
                TextBox textBox = e.Control as TextBox;

                if (textBox != null)
                {
                    textBox.KeyPress += new KeyPressEventHandler(Column_KeyPress);
                }
            }
        }
        private void Column_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

      
    }
}
