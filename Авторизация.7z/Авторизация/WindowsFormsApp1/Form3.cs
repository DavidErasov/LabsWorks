﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }
        //Кнопка выхода
        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Форма Главного меню
        private void button1_Click(object sender, EventArgs e)
        {
            Main NextForm = new Main(); //Переход с Form3 на Main
            NextForm.Show();
            this.Close();
        }
        //Форма сообщения
        private void button2_Click(object sender, EventArgs e)
        {
            Massage nextform = new Massage(); //Переход с Form3 на Massage
            nextform.Show();
            this.Hide();

        }
        //Форма архива
        private void button3_Click(object sender, EventArgs e) 
        {
            archive nextform = new archive(); //Переход с Form3 на archive
            nextform.Show();
            this.Hide();
        }
    }
}
