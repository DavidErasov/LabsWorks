﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        //Кнопка выхода
        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit(); //Выход
        }
        //Кнопка назад
        private void button1_Click(object sender, EventArgs e)
        {
            Form3 BackForm = new Form3(); //Переход с Main на Form3
            BackForm.Show();
            this.Hide();
        }
    }
}
