﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba8
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        Model2 db2 = new Model2();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ordersBindingSource.DataSource = db.Orders.ToList();
            customersBindingSource.DataSource = db2.Customers.ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ordersBindingSource.DataSource = db.Orders.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string n = (string)comboBox1.SelectedValue;
            ordersBindingSource.DataSource = db.Orders.Where(x => x.CustomerID == n).ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
             ordersBindingSource.DataSource = db.Orders.OrderBy(c => c.CustomerID).ThenBy(c=>c.OrderDate).ToList();
        }
    }
}
